using System;
using NUnit.Framework;
using Expedia;
using Rhino.Mocks;
using System.Collections.Generic;

namespace ExpediaTest
{
	[TestFixture()]
	public class CarTest
	{	
		private Car targetCar;
		private MockRepository mocks;
		
		[SetUp()]
		public void SetUp()
		{
			targetCar = new Car(5);
			mocks = new MockRepository();
		}
		
		[Test()]
		public void TestThatCarInitializes()
		{
			Assert.IsNotNull(targetCar);
		}	
		
		[Test()]
		public void TestThatCarHasCorrectBasePriceForFiveDays()
		{
			Assert.AreEqual(50, targetCar.getBasePrice()	);
		}
		
		[Test()]
		public void TestThatCarHasCorrectBasePriceForTenDays()
		{
            var target = new Car(10);
			Assert.AreEqual(80, target.getBasePrice());	
		}
		
		[Test()]
		public void TestThatCarHasCorrectBasePriceForSevenDays()
		{
			var target = new Car(7);
			Assert.AreEqual(10*7*.8, target.getBasePrice());
		}
		
		[Test()]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void TestThatCarThrowsOnBadLength()
		{
			new Car(-5);
		}



        [Test()]
        public void TestThatCarLocationDoesGetLocationFromTheDatabase()
        {
            IDatabase mockDatabase = mocks.Stub<IDatabase>();
            String carLocation = "Right Here";
            String anotherCarLocation = "Over There";

            using (mocks.Record())
            {
                // The mock will return "Right Here" when the call is made with car number 132
                mockDatabase.getCarLocation(132);
                LastCall.Return(carLocation);
                // The mock will return "Over There" when the call is made with 1337
                mockDatabase.getCarLocation(1337);
                LastCall.Return(anotherCarLocation);
            }

            var target = new Car(12);

            target.Database = mockDatabase;

            String result;
            result = target.getCarLocation(1337);
            Assert.AreEqual(result, anotherCarLocation);
            result = target.getCarLocation(132);
            Assert.AreEqual(result, carLocation);
        }

        [Test()]
        public void TestThatCarDoesGetMileageCountFromDatabase()
        {

            IDatabase mockDatabase = mocks.Stub<IDatabase>();
            int miles = 15000;

            mockDatabase.Miles = miles;


            var target = new Car(10);
            target.Database = mockDatabase;

            int mileage = target.Mileage;
            Assert.AreEqual(miles, mileage);
        }

        [Test()]
        public void TestThatCarMotherInitializesTheCorrectCar()
        {
            string name1 = "BMW M3 Shiny Car of Awesome";
            string name2 = "Saab 9-5 Sports Sedan";

            Car bmw = ObjectMother.BMW();
            Car saab = ObjectMother.Saab();

            Assert.NotNull(saab);
            Assert.NotNull(bmw);

            Assert.AreEqual(name2, saab.Name);
            Assert.AreEqual(name1, bmw.Name);          
        }

	}
}
